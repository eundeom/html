export default class employee {
  constructor(Employeeid, first_name, last_name, years, married, children) {
    (Employeeid = employee.Employeeid),
      (first_name = employee.first_name),
      (last_name = employee.last_name),
      (years = employee.years),
      (married = employee.married),
      (children = employee.children);
  }

  //   onTable = () => {
  //     for (let em of employee) {
  //       const tr = document.createElement("tr");
  //       for (let emi of em) {
  //         const td = document.createElement("td");
  //         td = em[emi];
  //       }
  //     }
  //   };
}
